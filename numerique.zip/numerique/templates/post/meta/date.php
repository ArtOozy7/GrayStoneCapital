<div class="post-date vamtam-meta-date">
	<a href="<?php the_permalink() ?>" title="<?php the_title_attribute() ?>">
		<?php the_time( get_option( 'date_format' ) ); ?>
	</a>
</div>
