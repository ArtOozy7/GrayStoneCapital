<?php

return array(
	'header-logo-type' => 'image',
	'wc-product-gallery-zoom' => 'disabled',
	'google_fonts' => '',
	'custom-js' => '',
);
