<?php

class Vamtam_Customizer_Section extends WP_Customize_Section {
	public $type = 'vamtam';
}
